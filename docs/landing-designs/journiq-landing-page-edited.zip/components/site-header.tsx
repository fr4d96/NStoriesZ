import Link from "next/link";
import { MobileNavToggle } from "@/components/mobile-nav-toggle";
import { ThemeToggle } from "@/components/theme-toggle";

const primaryNav = [
  { href: "/#stories", label: "Stories" },
  { href: "/#regions", label: "Destinations" },
  { href: "/#how", label: "Work Guides" },
  { href: "/about", label: "About" },
];

export function SiteHeader() {
  return (
    <header className="journiq-header sticky top-0 z-40 -mb-[76px] text-white">
      <div className="mx-auto flex min-h-[76px] max-w-[1160px] items-center gap-5 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5 text-xl font-black tracking-tight">
          <span className="grid h-9 w-9 -rotate-12 place-items-center rounded-full border border-current">↗</span>
          Journiq
        </Link>
        <nav aria-label="Primary" className="ml-auto hidden items-center gap-6 text-sm font-bold md:flex">
          {primaryNav.map((item) => <Link key={item.href} href={item.href} className="journiq-nav-link">{item.label}</Link>)}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <ThemeToggle />
          <Link href="/sign-in" className="rounded-full border border-current px-4 py-2 text-sm font-bold">Sign in</Link>
          <Link href="/sign-up" className="rounded-full bg-accent px-4 py-2 text-sm font-black text-accent-foreground">Share your story</Link>
        </div>
        <div className="ml-auto flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <MobileNavToggle navItems={[...primaryNav,{ href: "/sign-in", label: "Sign in" },{ href: "/sign-up", label: "Share your story" }]} />
        </div>
      </div>
    </header>
  );
}
