"use client";

import { useEffect, useRef, useState } from "react";
import { FeaturedStorySlide } from "@/components/home/featured-story-slide";
import type { StoryCardData } from "@/components/story/story-card";

type StackVars = React.CSSProperties & Record<string, string | number>;

const DEPTH_STYLE: Record<number, StackVars> = {
  0: {
    "--stack-x": "0px",
    "--stack-y": "0px",
    "--stack-scale": 1,
    "--stack-rotate": "0deg",
    zIndex: 6,
    opacity: 1,
  },
  1: {
    "--stack-x": "14px",
    "--stack-y": "14px",
    "--stack-scale": 0.97,
    "--stack-rotate": "1.6deg",
    zIndex: 5,
    opacity: 0.95,
  },
  2: {
    "--stack-x": "-13px",
    "--stack-y": "27px",
    "--stack-scale": 0.94,
    "--stack-rotate": "-2deg",
    zIndex: 4,
    opacity: 0.85,
  },
  3: {
    "--stack-x": "9px",
    "--stack-y": "38px",
    "--stack-scale": 0.91,
    "--stack-rotate": "1deg",
    zIndex: 3,
    opacity: 0.7,
  },
};

const HIDDEN_STYLE: StackVars = {
  "--stack-y": "48px",
  "--stack-scale": 0.88,
  zIndex: 1,
  opacity: 0,
  pointerEvents: "none",
};

const DRAG_THRESHOLD = 80;
const VELOCITY_THRESHOLD = 0.55;
const THROW_DURATION_MS = 520;

function mod(n: number, m: number) {
  return ((n % m) + m) % m;
}

/**
 * Drag/swipe, depth-layered card stack -- the top card can be dragged left
 * or right (pointer events), thrown past a distance/velocity threshold, or
 * advanced with the prev/next buttons, dots, or arrow keys. Position is
 * tracked as a plain `slide` index (not read back from layout, unlike the
 * scroll-snap carousel this replaces) since nothing here scrolls.
 */
export function FeaturedStoryStack({ stories }: { stories: StoryCardData[] }) {
  const count = stories.length;
  const [slide, setSlide] = useState(0);
  const [throwState, setThrowState] = useState<{
    id: string;
    direction: "left" | "right";
  } | null>(null);
  const [dragState, setDragState] = useState<{
    id: string;
    x: number;
    rotate: number;
  } | null>(null);
  const animatingRef = useRef(false);
  const reducedRef = useRef(false);
  const dragRef = useRef<{
    id: string;
    pointerId: number;
    startX: number;
    lastX: number;
    startedAt: number;
  } | null>(null);

  useEffect(() => {
    reducedRef.current = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
  }, []);

  function moveStack(direction: 1 | -1, targetIndex?: number) {
    if (animatingRef.current || count < 2) return;
    animatingRef.current = true;
    const outgoing = stories[slide];
    setThrowState({
      id: outgoing.story_id,
      direction: direction > 0 ? "left" : "right",
    });
    const nextSlide =
      targetIndex !== undefined
        ? mod(targetIndex, count)
        : mod(slide + direction, count);
    setSlide(nextSlide);
    window.setTimeout(
      () => {
        setThrowState(null);
        animatingRef.current = false;
      },
      reducedRef.current ? 0 : THROW_DURATION_MS,
    );
  }

  function goTo(index: number) {
    if (index === slide || animatingRef.current) return;
    const forward = mod(index - slide, count);
    const backward = mod(slide - index, count);
    moveStack(forward <= backward ? 1 : -1, index);
  }

  function handleKeyDown(event: React.KeyboardEvent) {
    if (event.key === "ArrowRight") {
      event.preventDefault();
      moveStack(1);
    } else if (event.key === "ArrowLeft") {
      event.preventDefault();
      moveStack(-1);
    }
  }

  // Named/attached directly to their JSX event props (not wrapped in an
  // inline closure that also threads extra arguments) so the react-hooks
  // purity check recognizes these as real event handlers -- the story id
  // and active flag they need come from the card's own data-* attributes
  // instead of a closure. Timing uses the event's own `timeStamp` rather
  // than calling performance.now(), which the same purity check treats as
  // an impure global regardless of call site.
  function handlePointerDown(event: React.PointerEvent<HTMLDivElement>) {
    const card = event.currentTarget;
    if (card.dataset.active !== "true" || event.button !== 0) return;
    if ((event.target as HTMLElement).closest("a,button")) return;
    dragRef.current = {
      id: card.dataset.storyId ?? "",
      pointerId: event.pointerId,
      startX: event.clientX,
      lastX: event.clientX,
      startedAt: event.timeStamp,
    };
    try {
      card.setPointerCapture(event.pointerId);
    } catch {
      // not supported in this environment (e.g. jsdom) -- drag still works
    }
  }

  function handlePointerMove(event: React.PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    drag.lastX = event.clientX;
    const distance = Math.max(-320, Math.min(320, event.clientX - drag.startX));
    setDragState({ id: drag.id, x: distance, rotate: distance / 24 });
  }

  function releaseCapture(event: React.PointerEvent<HTMLDivElement>) {
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // pointer capture may already be released
    }
  }

  function handlePointerUp(event: React.PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    dragRef.current = null;
    const distance = drag.lastX - drag.startX;
    const elapsed = Math.max(1, event.timeStamp - drag.startedAt);
    const velocity = distance / elapsed;
    releaseCapture(event);
    setDragState(null);
    // The velocity check also requires a minimum distance -- otherwise a
    // sub-pixel jitter paired with a near-zero elapsed time (two pointer
    // events firing on the same frame) computes as an enormous velocity and
    // throws the card on what was really just a tap.
    const isFlick =
      Math.abs(distance) > 12 && Math.abs(velocity) > VELOCITY_THRESHOLD;
    if (Math.abs(distance) > DRAG_THRESHOLD || isFlick) {
      moveStack(distance < 0 ? 1 : -1);
    }
  }

  function handlePointerCancel(event: React.PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    dragRef.current = null;
    releaseCapture(event);
    setDragState(null);
  }

  if (count === 0) return null;

  const active = stories[slide];

  return (
    <div
      role="region"
      aria-roledescription="carousel"
      aria-label="Featured Working Holiday stories"
      className="relative"
    >
      <div
        tabIndex={0}
        onKeyDown={handleKeyDown}
        className="relative mx-auto h-[735px] max-w-[1080px] outline-none sm:h-[620px]"
      >
        {stories.map((story, index) => {
          const depth = mod(index - slide, count);
          const isActive = depth === 0;
          const isThrowing = throwState?.id === story.story_id;
          const isDragging = dragState?.id === story.story_id;
          const style: StackVars = {
            ...(depth <= 3 ? DEPTH_STYLE[depth] : HIDDEN_STYLE),
          };
          if (isDragging && dragState) {
            style["--drag-x"] = `${dragState.x}px`;
            style["--drag-rotate"] = `${dragState.rotate}deg`;
          }
          const throwClass = isThrowing
            ? throwState?.direction === "left"
              ? "is-throwing-left"
              : "is-throwing-right"
            : "";

          return (
            <div
              key={story.story_id}
              data-testid="stack-card"
              data-active={isActive}
              data-story-id={story.story_id}
              className={`story-stack-card absolute inset-0 ${isActive ? "cursor-grab" : ""} ${isDragging ? "is-dragging cursor-grabbing" : ""} ${throwClass}`}
              style={style}
              aria-hidden={!isActive}
              inert={!isActive}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerCancel}
            >
              <FeaturedStorySlide story={story} priority={index === 0} />
            </div>
          );
        })}
      </div>

      <div aria-live="polite" className="sr-only">
        {`Story ${slide + 1} of ${count}: ${active.title}`}
      </div>

      <div className="mt-16 flex flex-wrap items-center justify-center gap-3">
        <button
          type="button"
          aria-label="Previous stories"
          onClick={() => moveStack(-1)}
          className="flex h-11 w-11 items-center justify-center rounded-full border border-border-subtle text-foreground transition-transform hover:-translate-y-0.5 hover:bg-surface-muted"
        >
          <span aria-hidden="true">&larr;</span>
        </button>
        <div className="flex items-center gap-1.5">
          {stories.map((story, index) => (
            <button
              key={story.story_id}
              type="button"
              aria-label={`Go to story ${index + 1} of ${count}`}
              aria-current={index === slide ? "true" : undefined}
              onClick={() => goTo(index)}
              className={`h-1.5 rounded-full transition-all hover:scale-125 ${
                index === slide ? "w-5 bg-accent" : "w-1.5 bg-border-subtle"
              }`}
            />
          ))}
        </div>
        <button
          type="button"
          aria-label="Next stories"
          onClick={() => moveStack(1)}
          className="flex h-11 w-11 items-center justify-center rounded-full border border-border-subtle text-foreground transition-transform hover:-translate-y-0.5 hover:bg-surface-muted"
        >
          <span aria-hidden="true">&rarr;</span>
        </button>
      </div>
      <p className="mt-3 text-center text-xs text-foreground/50">
        Drag the front card, or use the arrows.
      </p>
    </div>
  );
}
